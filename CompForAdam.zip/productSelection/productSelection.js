import { LightningElement } from 'lwc';

export default class ProductSelection extends LightningElement {
    items=[
        {
          "id": "1",
          "name": "Item 1 jhkjhk jhk hkhbhk jhk ",
          "description": "This is item 1.",
          "selected": false,
          "cardClass": "card"
        },
        {
          "id": "2",
          "name": "Item 2",
          "description": "This is item 2.",
          "selected": true,
          "cardClass": "card selectable-card--selected"
        },
        {
          "id": "3",
          "name": "Item 3",
          "description": "This is item 3.",
          "selected": false,
          "cardClass": "card"
        },
        {
          "id": "4",
          "name": "Item 4",
          "description": "This is item 4.",
          "selected": false,
          "cardClass": "card"
        },
        {
          "id": "5",
          "name": "Item 5",
          "description": "This is item 5.",
          "selected": false,
          "cardClass": "card"
        },
        {
          "id": "6",
          "name": "Item 6",
          "description": "This is item 6.",
          "selected": false,
          "cardClass": "card"
        },
        {
          "id": "7",
          "name": "Item 7",
          "description": "This is item 7.",
          "selected": false,
          "cardClass": "card"
        },
        {
          "id": "8",
          "name": "Item 8",
          "description": "This is item 8.",
          "selected": false,
          "cardClass": "card"
        },
        {
          "id": "9",
          "name": "Item 9",
          "description": "This is item 9.",
          "selected": false,
          "cardClass": "card"
        } ];
      
        rows=[{"id": "9"},{"id": "10"}];
        
handleCardSelect(e)
{
    console.log(" Selected or Nor? "+e.detail + " id updated "+e.target.keyId);
}

}