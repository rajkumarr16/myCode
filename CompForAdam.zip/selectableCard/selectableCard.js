import { LightningElement, api } from 'lwc';

export default class SelectableCard extends LightningElement {
    @api selected = false;
    @api cardClass = 'card';    
    @api keyId;
    handleClick(e) {
        this.selected = !this.selected;
        this.cardClass = this.selected ? ' card card-with-shadow-and-tick  selected' : 'card';
        this.dispatchEvent(new CustomEvent('select', { detail: this.selected,keyId:this.keyId}));
    }
}
